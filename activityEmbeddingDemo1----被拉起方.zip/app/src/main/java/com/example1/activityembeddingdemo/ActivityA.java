package com.example1.activityembeddingdemo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.window.embedding.ActivityFilter;
import androidx.window.embedding.ActivityRule;
import androidx.window.embedding.SplitController;
import androidx.window.embedding.SplitInfo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import androidx.core.util.Consumer;

public class ActivityA extends AppCompatActivity implements View.OnClickListener {

    Handler handler = null;
    private SplitInfoCallback mCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);

        mCallback = new SplitInfoCallback();
        SplitController.getInstance().addSplitListener(this, this.getMainExecutor(), mCallback);

        findViewById(R.id.start_activity_b).setOnClickListener(this);
        findViewById(R.id.start_activity_c).setOnClickListener(this);
        findViewById(R.id.start_activity_d).setOnClickListener(this);
        findViewById(R.id.start_activity_e).setOnClickListener(this);
        findViewById(R.id.start_activity_f).setOnClickListener(this);
        findViewById(R.id.start_activity_g).setOnClickListener(this);

        handler = new Handler(Looper.myLooper());

        Log.e("11111111", "isActivityEmbeddedC:" + SplitController.getInstance().isActivityEmbedded(ActivityA.this));
    }

    class SplitInfoCallback implements Consumer<List<SplitInfo>> {
        @Override
        public void accept(List<SplitInfo> splitInfoList) {
            Log.e("11111111", "accept");
            for (SplitInfo s : splitInfoList) {
                Log.e("11111111", "s:" + s);
            }
            Log.e("11111111", "isActivityEmbeddedA:" + SplitController.getInstance().isActivityEmbedded(ActivityA.this));
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        Log.e("11111111", "isActivityEmbeddedB:" + SplitController.getInstance().isActivityEmbedded(ActivityA.this));
        super.onConfigurationChanged(newConfig);
    }

    ComponentName componentName(Class<? extends Activity> activityClass) {
        return new ComponentName(getPackageName(),
                activityClass != null ? activityClass.getName() : "*");
    }

    private Runnable mDelayRunnable = new Runnable(){
        @Override
        public void run() {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_activity_b:
                Intent intent = new Intent();
                ComponentName cp = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityB");
                intent.setComponent(cp);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;

            case R.id.start_activity_c:
//                Intent intent1 = new Intent();
//                ComponentName cp1 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityC");
//                intent1.setComponent(cp1);
//                startActivity(intent1);
                //SplitActivityPlaceholder.getInstance().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                //SplitActivityPlaceholder.getInstance().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

                Set<ActivityFilter> activityFilters1 = new HashSet<>();
                activityFilters1.add(new ActivityFilter(componentName(ActivityB.class), null));
                ActivityRule activityRule1 = new ActivityRule(activityFilters1, true);
                SplitController.getInstance().unregisterRule(activityRule1);
                Intent intent1 = new Intent();
                ComponentName cp1 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityB");
                intent1.setComponent(cp1);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                //startActivity(intent1);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                break;

            case R.id.start_activity_d:
//                Intent intent2 = new Intent();
//                ComponentName cp2 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityD");
//                intent2.setComponent(cp2);
//                startActivity(intent2);
                //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                ActivityB.getInstance().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

//                Set<ActivityFilter> activityFilters2 = new HashSet<>();
//                activityFilters2.add(new ActivityFilter(componentName(ActivityB.class), null));
//                ActivityRule activityRule2 = new ActivityRule(activityFilters2, true);
//                SplitController.getInstance().registerRule(activityRule2);
//                Intent intent2 = new Intent();
//                ComponentName cp2 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityB");
//                intent2.setComponent(cp2);
//                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                //startActivity(intent2);

                //handler.postDelayed(mDelayRunnable, 300);
                //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;

            case R.id.start_activity_e:
                Intent intent3 = new Intent();
                ComponentName cp3 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityE");
                intent3.setComponent(cp3);
                startActivity(intent3);
                break;

            case R.id.start_activity_f:
                Intent intent4 = new Intent();
                ComponentName cp4 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityF");
                intent4.setComponent(cp4);
                startActivity(intent4);
                break;

            case R.id.start_activity_g:
                Intent intent5 = new Intent();
                ComponentName cp5 = new ComponentName("com.example1.sdkdemo", "com.example1.sdkdemo.MainActivity");
                intent5.setComponent(cp5);
                intent5.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent5);
                break;
            default:
                break;
        }
    }
}