package com.example1.activityembeddingdemo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.window.embedding.ActivityFilter;
import androidx.window.embedding.ActivityRule;
import androidx.window.embedding.SplitController;

import java.util.HashSet;
import java.util.Set;

public class ActivityB extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        findViewById(R.id.start_activity_e).setOnClickListener(this);
        findViewById(R.id.finish_activity_b).setOnClickListener(this);
    }

    private static class LazyHolder {
        private static final ActivityB INSTANCE = new ActivityB();
    }

    public static ActivityB getInstance() {
        return ActivityB.LazyHolder.INSTANCE;
    }

    ComponentName componentName(Class<? extends Activity> activityClass) {
        return new ComponentName(getPackageName(),
                activityClass != null ? activityClass.getName() : "*");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_activity_e:
//                Intent intent3 = new Intent();
//                ComponentName cp3 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityE");
//                intent3.setComponent(cp3);
//                startActivity(intent3);

                Set<ActivityFilter> activityFilters2 = new HashSet<>();
                activityFilters2.add(new ActivityFilter(componentName(ActivityB.class), null));
                ActivityRule activityRule2 = new ActivityRule(activityFilters2, true);
                SplitController.getInstance().registerRule(activityRule2);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;

            case R.id.finish_activity_b:
                finish();
                break;

            default:
                break;
        }
    }
}