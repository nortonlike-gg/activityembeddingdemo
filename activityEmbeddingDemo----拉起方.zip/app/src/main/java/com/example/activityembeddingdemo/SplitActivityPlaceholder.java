package com.example.activityembeddingdemo;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SplitActivityPlaceholder extends AppCompatActivity{
    private static class LazyHolder {
        private static final SplitActivityPlaceholder INSTANCE = new SplitActivityPlaceholder();
    }

    public static SplitActivityPlaceholder getInstance() {
        return SplitActivityPlaceholder.LazyHolder.INSTANCE;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.split_activity_placeholder);
    }
}