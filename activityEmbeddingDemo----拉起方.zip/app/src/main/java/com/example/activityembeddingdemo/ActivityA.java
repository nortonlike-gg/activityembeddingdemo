package com.example.activityembeddingdemo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Consumer;
import androidx.window.embedding.ActivityFilter;
import androidx.window.embedding.ActivityRule;
import androidx.window.embedding.SplitController;
import androidx.window.embedding.SplitInfo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ActivityA extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "ActivityA";
    private SplitInfoCallback mCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);

        mCallback = new SplitInfoCallback();
        SplitController.getInstance().addSplitListener(this, this.getMainExecutor(), mCallback);

        findViewById(R.id.start_activity_b).setOnClickListener(this);
        findViewById(R.id.start_activity_c).setOnClickListener(this);
        findViewById(R.id.start_activity_d).setOnClickListener(this);
        findViewById(R.id.start_activity_e).setOnClickListener(this);
        findViewById(R.id.start_activity_f).setOnClickListener(this);
        findViewById(R.id.start_activity_g).setOnClickListener(this);
        findViewById(R.id.start_activity_h).setOnClickListener(this);
    }

    class SplitInfoCallback implements Consumer<List<SplitInfo>> {
        @Override
        public void accept(List<SplitInfo> splitInfoList) {
            Log.e(TAG, "accept");
            for (SplitInfo s : splitInfoList) {
                Log.e(TAG, "s:" + s);
            }
            Log.e(TAG, "isActivityEmbedded:" + SplitController.getInstance().isActivityEmbedded(ActivityA.this));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_activity_b:
                Intent intent = new Intent();
                ComponentName cp = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityB");
                intent.setComponent(cp);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;

            case R.id.start_activity_c:
                Intent intent1 = new Intent();
                ComponentName cp1 = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityC");
                intent1.setComponent(cp1);
                startActivity(intent1);
                break;

            case R.id.start_activity_d:
                Intent intent2 = new Intent();
                ComponentName cp2 = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityD");
                intent2.setComponent(cp2);
                startActivity(intent2);
                break;

            case R.id.start_activity_e:
                Intent intent3 = new Intent();
                ComponentName cp3 = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityE");
                intent3.setComponent(cp3);
                startActivity(intent3);
                break;

            case R.id.start_activity_f:
                Intent intent4 = new Intent();
                ComponentName cp4 = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityF");
                intent4.setComponent(cp4);
                startActivity(intent4);
                break;

            case R.id.start_activity_g:
                Intent intent5 = new Intent();
                ComponentName cp5 = new ComponentName("com.example1.activityembeddingdemo", "com.example1.activityembeddingdemo.ActivityA");
                intent5.setComponent(cp5);
                intent5.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent5);
                break;

            case R.id.start_activity_h:
                Intent intent6 = new Intent();
                ComponentName cp6 = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityH");
                intent6.setComponent(cp6);
                intent6.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent6);
                break;
            default:
                break;
        }
    }
}