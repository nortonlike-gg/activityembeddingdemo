package com.example.activityembeddingdemo;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityE extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e);

        findViewById(R.id.start_activity_b).setOnClickListener(this);
        findViewById(R.id.finish_activity_e).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_activity_b:
                Intent intent = new Intent();
                ComponentName cp = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.ActivityB");
                intent.setComponent(cp);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;

            case R.id.finish_activity_e:
                finish();
                break;

            default:
                break;
        }
    }
}