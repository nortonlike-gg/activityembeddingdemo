package com.example.activityembeddingdemo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.window.embedding.ActivityFilter;
import androidx.window.embedding.ActivityRule;
import androidx.window.embedding.SplitController;

import java.util.HashSet;
import java.util.Set;

public class ActivityH extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h);

        findViewById(R.id.request_fullscreenL_h).setOnClickListener(this);
        findViewById(R.id.request_fullscreenP_h).setOnClickListener(this);
        findViewById(R.id.revcover_h).setOnClickListener(this);
        findViewById(R.id.finish_activity_h).setOnClickListener(this);
    }

    ComponentName componentName(Class<? extends Activity> activityClass) {
        return new ComponentName(getPackageName(),
                activityClass != null ? activityClass.getName() : "*");
    }

    @Override
    protected void onDestroy() {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

        Set<ActivityFilter> activityFilters3 = new HashSet<>();
        activityFilters3.add(new ActivityFilter(componentName(ActivityH.class), null));
        ActivityRule activityRule3 = new ActivityRule(activityFilters3, true);
        SplitController.getInstance().unregisterRule(activityRule3);
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.request_fullscreenL_h:
                Set<ActivityFilter> activityFilters1 = new HashSet<>();
                activityFilters1.add(new ActivityFilter(componentName(ActivityH.class), null));
                ActivityRule activityRule1 = new ActivityRule(activityFilters1, true);
                SplitController.getInstance().registerRule(activityRule1);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                break;

            case R.id.request_fullscreenP_h:
                Set<ActivityFilter> activityFilters2 = new HashSet<>();
                activityFilters2.add(new ActivityFilter(componentName(ActivityH.class), null));
                ActivityRule activityRule2 = new ActivityRule(activityFilters2, true);
                SplitController.getInstance().registerRule(activityRule2);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;

            case R.id.revcover_h:
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

                Set<ActivityFilter> activityFilters3 = new HashSet<>();
                activityFilters3.add(new ActivityFilter(componentName(ActivityH.class), null));
                ActivityRule activityRule3 = new ActivityRule(activityFilters3, true);
                SplitController.getInstance().unregisterRule(activityRule3);
                break;

            case R.id.finish_activity_h:
                finish();
                break;

            default:
                break;
        }
    }
}