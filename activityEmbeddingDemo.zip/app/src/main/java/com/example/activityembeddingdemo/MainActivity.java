package com.example.activityembeddingdemo;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.secondActivity).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.secondActivity:
                Intent intent = new Intent();
                ComponentName cp = new ComponentName("com.example.activityembeddingdemo", "com.example.activityembeddingdemo.SecondActivity");
                intent.setComponent(cp);
                startActivity(intent);
                break;

            default:
                break;
        }
    }
}